from flask import Flask, render_template, request
from Runn import ans

app = Flask(__name__)

@app.route('/')
def hello_world():
	return render_template('index.html')

@app.route('/',methods=["GET", "POST"])
def print_ans():
	if request.method=="POST":
		n=request.form.get("nodes")
		arr=request.form.get("vals")
		n=int(n)
		s=arr.split(' ')
		print(type(s[0]))
		Ans=ans(n,s)
		return Ans
		return render_template('index.html',As=Ans)

if __name__ == '__main__':
	app.run()
